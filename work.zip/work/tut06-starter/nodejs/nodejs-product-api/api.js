const http = require("http");
const { getProducts, addProduct, updateProduct, deleteProduct } = require("./dataProvider");

// Import the getProducts function
const products = getProducts();
function findProductById(id) {
  return products.find((product) => product.id === parseInt(id));
}

const server = http.createServer((req, res) => {
  if (req.method === "GET" && req.url === "/products") {
    res.writeHead(200, { "Content-Type": "application/json" });
    res.end(JSON.stringify(products));
  } else if (req.method === "GET" && req.url.startsWith("/products/")) {
    const id = req.url.split("/")[2];
    const productById = findProductById(id);
    if (productById) {
      res.writeHead(200, { "Content-Type": "application/json" });
      res.end(JSON.stringify(productById));
    } else {
      res.writeHead(404, { "Content-Type": "application/json" });
      res.end(JSON.stringify({ message: "Product not found by ID" }));
    }
  } else if (req.method === "POST" && req.url === "/products") {
    if (req.method === "POST" && req.url === "/products") {
      let body = "";
      req.on("data", (chunk) => {
        body += chunk.toString();
      });
      req.on("end", () => {
        const { name, price } = JSON.parse(body);
        const newProduct = {
          id: products.length ? products[products.length - 1].id + 1 : 1,
          name,
          price,
        };
        products.push(newProduct);
        addProduct(newProduct);
        res.writeHead(201, { "Content-Type": "application/json" });
        res.end(JSON.stringify(newProduct));
      });
    }
  } else if (req.method === "PUT" && req.url.startsWith("/products/")) {
    const id = parseInt(req.url.split('/')[2]);
    console.log(id)
    let body = '';
    req.on("data", (chunk) => {
      body += chunk.toString();
    });

    req.on('end', () => {
      const { name, price } = JSON.parse(body);
      const productById = findProductById(id);
      if (productById) {
        productById.name = name || productById.name;
        productById.price = price || productById.price;
        updateProduct(id, { name, price });
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify(productById));
      } else {
        res.writeHead(404, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ message: 'Product not found' }));
      }
    })
  } else if (req.method === 'DELETE' && req.url.startsWith('/products/')) {
    const id = req.url.split('/')[2];
    const productById = findProductById(id);
    if (productById !== -1) {
      products.splice(productById, 1);
      deleteProduct(id);
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({
        message: 'Product deleted successfully'
      }));
    } else {
      res.writeHead(404, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ message: 'Product not found' }));
    }


  }
});

// In-memory array to hold products (initially populated from the JSON file)

// Create the server
const port = 3000;

// Start the server on port 3000
server.listen(port, () => {
  console.log(`Server is running on ${port}`);
});

'use strict';
const express = require('express');

const app = express();

app.get('/hello', (req, res) => {
    const name = req.query.name;
    if (name) {
        res.type('text/html');
        res.end(`<h1>Hello, ${name}</h1>`);
    } else {
        res.static(400).send({message: `Can't not find`});
    }
})

const port = 3000;
app.use(express.static('public'));
app.listen(port, () => {
    console.log(`Server is running on ${port}`);
})
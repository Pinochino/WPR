'use strict';
const express = require('express');

const app = express();

app.get('/math/circle/:r', (req, res) => {
    const radius = parseFloat(req.params.r);
    const area = Math.pow(radius, 2) * Math.PI;
    const circumference = Math.PI * 2 * radius;

    const object = {
        area: parseFloat(area.toFixed(2)),
        circumference: parseFloat(area.toFixed(2))
    }

   res.json(object);

})

const port = 3000;
app.use(express.static('public'));
app.listen(port, () => {
    console.log(`Server is running on ${port}`);
})
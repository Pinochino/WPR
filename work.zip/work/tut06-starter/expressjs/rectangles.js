'use strict';
const express = require('express');

const app = express();

app.get('/math/circle/:width/:height', (req, res) => {
    const width = parseInt(req.params.width);
    const height = parseInt(req.params.height)
    const area = width * height;
    const perimeter = (width + height) * 2;

    const object = {
        area: parseInt(area.toFixed(2)),
        perimeter: parseInt(perimeter.toFixed(2))
    }

   res.json(object);

})

const port = 3000;
app.use(express.static('public'));
app.listen(port, () => {
    console.log(`Server is running on ${port}`);
})
'use strict';
const express = require('express');

const app = express();

app.get('/hello', (req, res) => {
    res.type('text');
    res.send('Hello World');
})

const port = 3000;
app.use(express.static('public'));
app.listen(port, () => {
    console.log(`Server is running on ${port}`);
})